import React from 'react';
import { motion } from 'framer-motion';
import { Target, Lightbulb, Heart, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const AboutSection = () => {
  return (
    <section id="about" className="py-16 md:py-24 bg-white">
      <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 md:gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
          >
            <img  
              class="rounded-2xl shadow-2xl object-cover w-full h-auto max-h-[550px]" 
              alt="Diverse group of smiling community members and volunteers working together"
             src="https://images.unsplash.com/photo-1580982333389-cca46f167381" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.7, delay: 0.1, ease: "easeOut" }}
            className="space-y-6"
          >
            <span className="inline-block px-4 py-1.5 bg-dream-gold-light/30 text-dream-gold font-semibold text-xs rounded-full uppercase tracking-wider">
              Who We Are
            </span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-dream-purple-dark leading-tight">
              Fueling Change, <br />One Community at a Time.
            </h2>
            <p className="text-lg text-slate-700 leading-relaxed">
              Dreamlight Welfare Society is a passionate non-profit organization committed to uplifting underserved communities. We believe in creating sustainable solutions that empower individuals and foster self-reliance.
            </p>
            
            <div className="space-y-5 pt-3">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 bg-dream-purple-light/10 p-3 rounded-full mt-1">
                  <Target className="h-6 w-6 text-dream-purple" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-dream-purple-dark">Our Vision</h3>
                  <p className="text-slate-600 text-sm">A world where every individual has the opportunity to thrive with dignity and access to essential resources.</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 bg-dream-gold-light/20 p-3 rounded-full mt-1">
                  <Lightbulb className="h-6 w-6 text-dream-gold" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-dream-purple-dark">Our Mission</h3>
                  <p className="text-slate-600 text-sm">To implement impactful programs in education, healthcare, and livelihood, creating pathways to a brighter future.</p>
                </div>
              </div>
            </div>
            <div className="pt-4">
              <Link to="/about">
                <Button size="lg" variant="outline" className="border-2 border-dream-purple text-dream-purple hover:bg-dream-purple/10 rounded-full px-8 py-3 text-base font-semibold">
                  Learn More About Us
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;